/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package login;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author RC_Student_lab
 */
public class Login {
    private String registeredUsername;
    private String registeredPassword;
    private String registeredCellphone;
    private boolean isLoggedin = false;
    
    public Login(){}

    public boolean checkUsername(String username) {

        if (!username.contains("_")) {
            return false;
        }
        if (!(username.length() == 5)) {
            return false;
        }

        return true;
    }

    public boolean checkPassword(String password) {

        if (!(password.length() >= 8)) {
            return false;
        }

        Pattern pattern = Pattern.compile("^(?=.*[A-Z])(?=.*\\d)(?=.*[^a-zA-Z0-9]).{8,}$");
        Matcher matcher = pattern.matcher(password);
        return matcher.matches();
    }

    public boolean checkCellphone(String cellphone) {
        String mobileNumberRegex = "^\\+27(6\\d|7\\d|8[1-4])\\d{7}$";
        Pattern pattern = Pattern.compile(mobileNumberRegex);
        
        Matcher matcher = pattern.matcher(cellphone);
        return matcher.matches();
    }

    public boolean registerUser(String username, String password, String cellphone) {
        this.registeredUsername = username;
        this.registeredPassword = password;
        this.registeredCellphone = cellphone;
        return true;

    }

    public boolean loginuser(String username, String password) {
        isLoggedin = false;
        if (username.equals(registeredUsername) && password.equals(registeredPassword)) {
            isLoggedin = true;
            return true;
        } else {
            return false;
        }
    }
    
}
