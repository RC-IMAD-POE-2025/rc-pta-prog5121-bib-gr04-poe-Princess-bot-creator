/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import login.Login;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_lab
 */
public class LoginTests {
    
    public LoginTests() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
     @Test
    public void UsernameTests() {
        Login login = new Login();
         assertFalse(login.checkUsername("www"));
         assertFalse(login.checkUsername("wwww"));
         assertFalse(login.checkUsername("kyle!!!!!!"));
         assertTrue(login.checkUsername("kyl_1"));
    }
    
    @Test
    public void PasswordTests() {
        Login login = new Login();
        assertFalse(login.checkPassword("password"));
        assertFalse(login.checkPassword("rosebank"));
        assertFalse(login.checkPassword("Rosebank!"));
        assertTrue(login.checkPassword("Rosebank!1"));
    }
    
    @Test
    public void CellphoneTests() {
        Login login = new Login();
        assertFalse(login.checkCellphone("08966553"));
        assertTrue(login.checkPassword("+27838968966"));
    }
    
    @Test
    public void LoginTests() {
        Login login = new Login();
        login.registerUser("kyl_1", "Rosebank!1", "+27838968966");
        assertFalse(login.loginuser("wwww_", "Rosebank!1"));
        assertFalse(login.loginuser("kyl_1", "Rosebank"));
        assertTrue(login.loginuser("kyl_1", "Rosebank!1"));
    }
}
